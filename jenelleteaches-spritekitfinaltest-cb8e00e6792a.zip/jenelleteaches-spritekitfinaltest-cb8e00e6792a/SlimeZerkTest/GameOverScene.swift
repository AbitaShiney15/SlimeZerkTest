//
//  GameOverScene.swift
//  SlimeZerkTest
//
//  Created by MacStudent on 2019-02-25.
//  Copyright © 2019 Parrot. All rights reserved.
//

import Foundation
import SpriteKit
class GameOverScene: SKScene{
    init(size: CGSize, won:Bool) {
        super.init(size: size)
        
        let message = SKLabelNode(text:"GAME OVER!")
        message.position = CGPoint(x:self.size.width/2, y:self.size.height/2)
        message.fontColor = UIColor.magenta
        message.fontSize = 100
        message.fontName = "AvenirNext-Bold"
        addChild(message)
        // 4
        run(SKAction.sequence([
            SKAction.wait(forDuration: 3.0),
            SKAction.run() {
                //            let reveal = SKTransition.flipHorizontal(withDuration: 0.5)
                //            let scene = GameScene(size: self.size)
                //            scene.scaleMode = self.scaleMode
                //            self.view?.presentScene(scene, transition:reveal)
                
                let gameScene = GameScene(size: self.size)
                gameScene.scaleMode = .aspectFill
                
                //2.configure some animation on screen/scene
                let transitionEffect = SKTransition.flipVertical(withDuration: 2)
                // AudioPlayer.shared.setSounds(false)
                //3.Show the scene
                self.view?.presentScene(gameScene,transition: transitionEffect)
            }
            ]))
    }
    
    // 6
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
