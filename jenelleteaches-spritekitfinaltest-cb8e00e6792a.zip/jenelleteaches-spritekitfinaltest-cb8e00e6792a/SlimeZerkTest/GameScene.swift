//
//  GameScene.swift
//  SlimeZerkTest
//
//  Created by Parrot on 2019-02-25.
//  Copyright © 2019 Parrot. All rights reserved.
//

import SpriteKit
import GameplayKit

struct PhysicsCategory {
    static let none      : UInt32 = 0
    static let all       : UInt32 = UInt32.max
    static let player   : UInt32 = 0b1       // 1
    static let enemy: UInt32 = 0b10      // 2
    static let exit : UInt32 = 0b100  //4
    static let bullet : UInt32 = 0b1000      // 8
    static let walls : UInt32 = 0b10000 // //16
    static let border : UInt32 = 0b100000 //32
}

func +(left: CGPoint, right: CGPoint) -> CGPoint {
    return CGPoint(x: left.x + right.x, y: left.y + right.y)
}

func -(left: CGPoint, right: CGPoint) -> CGPoint {
    return CGPoint(x: left.x - right.x, y: left.y - right.y)
}

func *(point: CGPoint, scalar: CGFloat) -> CGPoint {
    return CGPoint(x: point.x * scalar, y: point.y * scalar)
}

func /(point: CGPoint, scalar: CGFloat) -> CGPoint {
    return CGPoint(x: point.x / scalar, y: point.y / scalar)
}

#if !(arch(x86_64) || arch(arm64))
func sqrt(a: CGFloat) -> CGFloat {
    return CGFloat(sqrtf(Float(a)))
}
#endif

extension CGPoint {
    func length() -> CGFloat {
        return sqrt(x*x + y*y)
    }
    
    func normalized() -> CGPoint {
        return self / length()
    }
}


class GameScene: SKScene {
    // MARK: Variables for tracking time
    private var lastUpdateTime : TimeInterval = 0
    
    // MARK: Sprite variables
    var player:SKSpriteNode = SKSpriteNode()
    var upButton:SKSpriteNode = SKSpriteNode()
    var downButton:SKSpriteNode = SKSpriteNode()
    var musicButton:SKSpriteNode = SKSpriteNode()
    var walls:SKSpriteNode = SKSpriteNode()
    var exit:SKSpriteNode = SKSpriteNode()
   // var enemy:SKSpriteNode = SKSpriteNode()
   let bgSound = SKAudioNode(fileNamed: "BackgroundMusic/ActionFighter.wav")
     var  backgroundSound = true
    var levelComplete = false
    var currentLevel = 1
   // var orange:Orange?
    // MARK: Label variables
   var livesLabel:SKLabelNode = SKLabelNode(text:"Lives-")
    
    var gameOver = false
   /// let playSound = SKAction.playSoundFileNamed("SpaceTrip.mp3",waitForCompletion: true)
  let stopSound: SKAction = SKAction.stop()
    var scoreLabel: SKLabelNode!
    //  var highScore: Int
    var score: Int = 0 {
        didSet {
            scoreLabel.text = "Score: \(score)"
        }
    }
    var lives = 1

    // MARK: Game state variables
   
    // MARK: Default GameScene functions
    // -------------------------------------
    override func didMove(to view: SKView) {
        self.lastUpdateTime = 0
        
        // get sprites from Scene Editor
        self.player = self.childNode(withName: "player") as! SKSpriteNode
        self.upButton = self.childNode(withName: "upButton") as! SKSpriteNode
        self.downButton = self.childNode(withName: "downButton") as! SKSpriteNode
      //  self.enemy = self.childNode(withName: "enemy") as! SKSpriteNode
        self.musicButton = self.childNode(withName: "musicButton") as! SKSpriteNode
        self.exit = self.childNode(withName: "exit") as! SKSpriteNode
        self.walls = self.childNode(withName: "walls") as! SKSpriteNode
        // get labels from Scene Editor
        self.scoreLabel = self.childNode(withName: "scoreLabel") as! SKLabelNode
        self.livesLabel = self.childNode(withName: "livesLabel") as! SKLabelNode
        self.livesLabel.text = "Lives: " + String(lives)
        
        player.physicsBody?.affectedByGravity = true
        player.physicsBody?.isDynamic = false
        player.physicsBody = SKPhysicsBody(circleOfRadius: player.size.width/2)
        player.physicsBody?.categoryBitMask = PhysicsCategory.player
        player.physicsBody?.contactTestBitMask = PhysicsCategory.enemy
        physicsWorld.gravity = .zero
        player.physicsBody?.collisionBitMask = PhysicsCategory.none
        physicsWorld.contactDelegate = self as! SKPhysicsContactDelegate
        NodeTest()
        
        //exit.physicsBody?.affectedByGravity = true
        exit.physicsBody?.isDynamic = true
        exit.physicsBody = SKPhysicsBody(rectangleOf: exit.size)
        exit.physicsBody?.categoryBitMask = PhysicsCategory.exit
        exit.physicsBody?.contactTestBitMask = PhysicsCategory.player
        exit.physicsBody?.collisionBitMask = PhysicsCategory.none
        
        addChild(bgSound)
    }
    
    func NodeTest(){
        for node in self.children {
            
            if (node.name == "enemy") {
                
                node.physicsBody?.isDynamic = true // 2
                node.physicsBody?.categoryBitMask = PhysicsCategory.enemy // 3
                node.physicsBody?.contactTestBitMask = PhysicsCategory.bullet | PhysicsCategory.player // 4
                node.physicsBody?.collisionBitMask = PhysicsCategory.bullet | PhysicsCategory.player // 5
                
                //name to the sprite
                node.name = "enemy"
                 let actualDuration = random(min: CGFloat(4.0) , max:CGFloat(8.0))
                node.position = CGPoint(x: size.width, y: actualDuration)
                let action = SKAction.move(to: player.position, duration: TimeInterval(actualDuration))
               let actionRepeat = SKAction.repeatForever(action)
                let actionDone = SKAction.removeFromParent()
                node.run(SKAction.sequence([action,actionRepeat,actionDone]))
                
                
            }
            else if(node.name == "walls"){
                node.name = "walls"
               // node.physicsBody?.affectedByGravity = true
                node.physicsBody?.isDynamic = false
                node.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: 125, height: 400))
                node.physicsBody?.categoryBitMask = PhysicsCategory.walls
                node.physicsBody?.contactTestBitMask = ~(PhysicsCategory.player) | ~(PhysicsCategory.enemy) | PhysicsCategory.bullet
                node.physicsBody?.collisionBitMask = PhysicsCategory.none

            }
        }
        
    }
    

    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else {
            // if the touch results in a null value, then exit
            return
        }
        
        // get the sprite that was touched
        let positionInScene = touch.location(in: self)
        var touchedNode = self.atPoint(positionInScene)
       
        
        // check the name of the sprite that was touched
        if let name = touchedNode.name
        {
            if name == "upButton"
            {
                touchedNode = touchedNode as! SKSpriteNode
                let moveAction: SKAction = SKAction.moveBy(x: 0, y: 200, duration: 1)
                //  let sequence = SKAction.sequence([moveAction, moveAction.reversed()])
                
                player.run(SKAction.repeatForever(moveAction), withKey:  "moving")
                player.run(moveAction)
            }
            else if name == "downButton"
            {
                touchedNode = touchedNode as! SKSpriteNode
                let moveAction: SKAction = SKAction.moveBy(x: 0, y: -200, duration: 1)
                //  let sequence = SKAction.sequence([moveAction, moveAction.reversed()])
                
                player.run(SKAction.repeatForever(moveAction), withKey:  "moving")
                player.run(moveAction)
            }
            else if name == "rightButton"
            {
                touchedNode = touchedNode as! SKSpriteNode
                let moveAction: SKAction = SKAction.moveBy(x: 200, y: 0, duration: 1)
                //  let sequence = SKAction.sequence([moveAction, moveAction.reversed()])
                player.xScale = 1
                player.run(SKAction.repeatForever(moveAction), withKey:  "moving")
                player.run(moveAction)
                
            }
            else if name == "leftButton"
            {
                touchedNode = touchedNode as! SKSpriteNode
                let moveAction: SKAction = SKAction.moveBy(x: -200, y: 0, duration: 1)
                //  let sequence = SKAction.sequence([moveAction, moveAction.reversed()])
                player.xScale = -1
                player.run(SKAction.repeatForever(moveAction), withKey:  "moving")
                player.run(moveAction)
            }
           else if name == "musicButton"
            {
                if backgroundSound == false{
                    bgSound.run(SKAction.play())
                    self.musicButton.texture = SKTexture(imageNamed: "musicOn-light")
                    backgroundSound = true
                }
                else  {
                    bgSound.run(SKAction.stop())
                    self.musicButton.texture = SKTexture(imageNamed: "musicOff-light")
                    backgroundSound = false
                    
                }
            }
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
       
    }
    
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else {
            return
        }
        
        let touchLocation = touch.location(in: self)
        
        //
        print(player.position.x);
        print(touchLocation.x);
        
        // set the initial location of projectiles
        let bullet = SKSpriteNode(imageNamed: "Orange")
        bullet.size = CGSize(width: 50, height: 50)
        bullet.position = player.position
       
        bullet.physicsBody = SKPhysicsBody(circleOfRadius: bullet.size.width/2)
        bullet.physicsBody?.isDynamic = true
        bullet.physicsBody?.categoryBitMask = PhysicsCategory.bullet
        bullet.physicsBody?.contactTestBitMask = PhysicsCategory.enemy
        bullet.physicsBody?.collisionBitMask = PhysicsCategory.none
        bullet.physicsBody?.usesPreciseCollisionDetection = true
        let action = SKAction.move(to: CGPoint(x:  400 * cos(bullet.zRotation) + bullet.position.x, y: 400 * sin(bullet.zRotation) + bullet.position.y),
            duration: 0.8)
      //  self.run(action)
        // defining the offset
        let offset = touchLocation - bullet.position
        if(offset.x<0){
            return
        }
        addChild(bullet)
        let direction = offset.normalized()
        
        let throwRate = direction * 1000
        
        let destination = throwRate + (bullet.position)
        
        // adding and creating the action
       // let action = SKAction.move(to: destination, duration: 2.0)
        let actionDone = SKAction.removeFromParent()
        bullet.run(SKAction.sequence([action,actionDone]))
        
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        
        // Initialize _lastUpdateTime if it has not already been
        if (self.lastUpdateTime == 0) {
            self.lastUpdateTime = currentTime
        }

        // Calculate time since last update
        let dt = currentTime - self.lastUpdateTime
    
        // HINT: This code prints "Hello world" every 5 seconds
        if (dt > 5) {
           // print("HELLO WORLD!")
            self.lastUpdateTime = currentTime
        }
       
        
    }
    func random() -> CGFloat {
        return CGFloat(Float(arc4random()) / 0xFFFFFFFF)
    }
    
    func random(min min: CGFloat, max: CGFloat) -> CGFloat {
        return random() * (max - min) + min
    }
    
    func gameOverFunc() {
        self.gameOver = true
        
        // increase the level number
        let message = SKLabelNode(text:"GAME OVER!")
        message.position = CGPoint(x:self.size.width/2, y:self.size.height/2)
        message.fontColor = UIColor.magenta
        message.fontSize = 100
        message.fontName = "AvenirNext-Bold"
        addChild(message)
        perform(#selector(GameScene.restartGame), with: nil, afterDelay: 3)
    

    }
    
    @objc func restartGame() {
        // load Level2.sks
        let scene = GameScene(fileNamed:"BerzerkLevel1")
        scene!.scaleMode = scaleMode
        view!.presentScene(scene)
    }
    
    func setLevel(levelNumber:Int) {
        self.currentLevel = levelNumber
    }
    
    func LevelNext(){
        self.levelComplete = true
        
        // load the next level
        self.currentLevel = self.currentLevel + 1
        
        // try to load the next level
        guard let nextLevelScene = GameScene.loadLevel(levelNumber: self.currentLevel) else {
            print("Error when loading next level")
            return
        }
        
        // wait 1 second then switch to next leevl
        let waitAction = SKAction.wait(forDuration:1)
        
        let showNextLevelAction = SKAction.run {
            nextLevelScene.setLevel(levelNumber: self.currentLevel)
            let transition = SKTransition.flipVertical(withDuration: 2)
            nextLevelScene.scaleMode = .aspectFill
            self.scene?.view?.presentScene(nextLevelScene, transition:transition)
        }
        
        let sequence = SKAction.sequence([waitAction, showNextLevelAction])
        
        self.run(sequence)
    }

//
   
    func playerDidCollidesEnemy(enemy: SKSpriteNode, player: SKSpriteNode) {
        print(" hit - player and enemy")
        enemy.removeFromParent()
        
        lives -= 1
        livesLabel.text = "Lives: " + String(lives)
        if(lives == 0){
            gameOverFunc()
        }
    }
    func bulletDidCollidesEnemy2(enemy: SKSpriteNode, bullet: SKSpriteNode) {
        print(" hit enemy and bullet ")
        enemy.removeFromParent()
        score += 50
    }
    func playerCollidesExit(player: SKSpriteNode,exit: SKSpriteNode){
        print("Move level i guess")
        self.LevelNext()
    }
    func playerHitWall(player: SKSpriteNode,walls: SKSpriteNode){
        print("u hit wall")
        player.physicsBody!.angularVelocity = 0;
        self.physicsBody!.velocity = CGVector(dx: 0, dy: 0)
       
        //if you would also like to stop any rotation that may be present
    }
    
   
}
    

extension GameScene: SKPhysicsContactDelegate{
    func didBegin(_ contact: SKPhysicsContact) {
        // 1
        var firstBody: SKPhysicsBody
        var secondBody: SKPhysicsBody
        if contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask {
            firstBody = contact.bodyA
            secondBody = contact.bodyB
        } else {
            firstBody = contact.bodyB
            secondBody = contact.bodyA
        }

        // 2
        if ((firstBody.categoryBitMask & PhysicsCategory.player != 0) &&
            (secondBody.categoryBitMask & PhysicsCategory.enemy != 0)) {
            if let enemy = firstBody.node as? SKSpriteNode,
                let player = secondBody.node as? SKSpriteNode {
                playerDidCollidesEnemy(enemy: enemy, player: player)
            }
        }
        else if ((firstBody.categoryBitMask & PhysicsCategory.enemy != 0) &&
            (secondBody.categoryBitMask & PhysicsCategory.bullet != 0)) {
            if let enemy = firstBody.node as? SKSpriteNode,
                let bullet = secondBody.node as? SKSpriteNode {
                bulletDidCollidesEnemy2(enemy: enemy, bullet: bullet)
            }
        }
        else if ((firstBody.categoryBitMask & PhysicsCategory.player != 0) &&
            (secondBody.categoryBitMask & PhysicsCategory.exit != 0)) {
            if let player = firstBody.node as? SKSpriteNode,
                let exit = secondBody.node as? SKSpriteNode {
                playerCollidesExit(player: player, exit: exit)
            }
        }
        else if ((firstBody.categoryBitMask & PhysicsCategory.player != 0) &&
            (secondBody.categoryBitMask & PhysicsCategory.walls != 0)) {
            if let player = firstBody.node as? SKSpriteNode,
                let walls = secondBody.node as? SKSpriteNode {
                playerHitWall(player: player, walls: walls)
               
            }
        }
    }
    class func loadLevel(levelNumber:Int) -> GameScene? {
        let fileName = "BerzerkLevel\(levelNumber)"
        
        // DEBUG nonsense
        print("Trying to load file: Level\(levelNumber).sks")
        
        guard let scene = GameScene(fileNamed: fileName) else {
            print("Cannot find level named: \(levelNumber).sks")
            return nil
        }
        
        scene.scaleMode = .aspectFill
        return scene
        
    }
    
}


